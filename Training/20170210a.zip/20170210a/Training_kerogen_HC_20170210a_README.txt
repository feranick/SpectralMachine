Format:
========

first raw corresponds to the Raman shift. If the spectra file used for predictions has a different scaling, it is rescaled to fit this. 

Second raw and beyond: first number is the H:C for the corresponding Raman intensity (second column and beyond).

Data included
==============
PPRG
AIDP
coal
GKF
gkp
Svalbard (BD43-3) row 152-156
Svalbard (J1646-174) row 157-164
Svalbard (PD5-98) row 165-171
Svalbard (S1B-G1643) row 172-181