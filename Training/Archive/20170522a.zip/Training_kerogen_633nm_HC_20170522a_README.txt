Last updated: 2017/05/22

Format:
========

first raw corresponds to the Raman shift. If the spectra file used for predictions has a different scaling, it is rescaled to fit this. 

Second raw and beyond: first number is the H:C for the corresponding Raman intensity (second column and beyond).

Data included
==============
PPRG
AIDP
coal
GKF
gkp
Svalbard (BD43-3) row 152-156
Svalbard (J1646-174) row 157-164
Svalbard (PD5-98) row 165-171
Svalbard (S1B-G1643) row 172-181
Sample-set (-,1,2,3)
UWM_Clark_14AS	SA03B_1.txt	H:C=0.16	row: 186
UWM_Clark_14AS	SA03B_2.txt	H:C=0.17	row: 187
UWM_Clark_14AS	SA03B_3.txt	H:C=0.17	row: 188
UWM_Clark_14AS	SA03C_3.txt	H:C=0.18	row: 189
UWM_Clark_14AS	SA03C_4.txt	H:C=0.15	row: 190
UWM_Clark_14AS	SA03C_5.txt	H:C=0.13	row: 192
UWM_Clark_14AS	SA03C_6.txt	H:C=0.15	row: 192
UWM_Clark_14AS	SA03D1_1.txt	H:C=0.17	row: 193
UWM_Clark_14AS	SA03D1_2.txt	H:C=0.13	row: 194
UWM_Clark_14AS	SA03D1_4.txt	H:C=0.18	row: 195
UWM_Clark_14AS	SA03D1_5.txt	H:C=0.15	row: 196
UWM_Clark_14AS	SA03D2_1.txt	H:C=0.16	row: 197
UWM_Clark_14AS	SA03D2_3.txt	H:C=0.19	row: 198
UWM_Clark_14AS	SA03D2_4.txt	H:C=0.14	row: 199
UWM_Clark_14AS	SA03D2_5.txt	H:C=0.14	row: 200
UWM_Clark_14AS	SA03D3_1.txt	H:C=0.13	row: 201
UWM_Clark_14AS	SA03D3_2.txt	H:C=0.19	row: 202
UWM_Clark_14AS	SA03D3_3.txt	H:C=0.18	row: 203
UWM_Clark_14AS	SA03D3_4.txt	H:C=0.19	row: 204
UWM_Clark_14AS	SA03D3_5.txt	H:C=0.13	row: 205
UWM_Clark_14AS	SA03D3_6.txt	H:C=0.13	row: 206
UWM_Clark_14AS	SA04A1_1.txt	H:C=0.17	row: 207
UWM_Clark_14AS	SA04A1_2.txt	H:C=0.18	row: 208
UWM_Clark_14AS	SA04A1_4.txt	H:C=0.16	row: 209
UWM_Clark_14AS	SA04A1_6.txt	H:C=0.15	row: 210
UWM_Clark_14AS	SA04A2_1.txt	H:C=0.13	row: 211
UWM_Clark_14AS	SA04A2_2.txt	H:C=0.15	row: 212
UWM_Clark_14AS	SA04A2_4.txt	H:C=0.19	row: 213
UWM_Clark_14AS	SA04A2_6.txt	H:C=0.12	row: 214
UWM_Clark_14AS	SA04A3_1.txt	H:C=0.16	row: 215
UWM_Clark_14AS	SA04A3_2.txt	H:C=0.18	row: 216
UWM_Clark_14AS	SA04A3_3.txt	H:C=0.18	row: 217
UWM_Clark_14AS	SA04A3_4.txt	H:C=0.16	row: 218
UWM_Clark_14AS	SA04A3_5.txt	H:C=0.14	row: 219
UWM_Clark_14AS	SA04B1_2.txt	H:C=0.16	row: 220
UWM_Clark_14AS	SA04B1_3.txt	H:C=0.14	row: 221
UWM_Clark_14AS	SA04B1_4.txt	H:C=0.15	row: 222
UWM_Clark_14AS	SA04B1_5.txt	H:C=0.14	row: 223
UWM_Clark_14AS	SA04B2_1.txt	H:C=0.2	row: 224
UWM_Clark_14AS	SA04B2_2.txt	H:C=0.17	row: 225
UWM_Clark_14AS	SA04B2_3.txt	H:C=0.13	row: 226
UWM_Clark_14AS	SA04B2_5.txt	H:C=0.11	row: 227
UWM_Clark_14AS	SA04B2_6.txt	H:C=0.18	row: 228
UWM_Clark_14AS	SA04B3_3.txt	H:C=0.12	row: 229
UWM_Clark_14AS	SA04B3_6.txt	H:C=0.13	row: 230
UWM_Clark_14AS	SA04B3_5.txt	H:C=0.14	row: 231
UWM_Clark_14AS	SA04C1_1.txt	H:C=0.19	row: 232
UWM_Clark_14AS	SA04C1_2.txt	H:C=0.18	row: 233
UWM_Clark_14AS	SA04C1_4.txt	H:C=0.11	row: 234
UWM_Clark_14AS	SA04C1_5.txt	H:C=0.14	row: 235
UWM_Clark_14AS	SA04C2_1.txt	H:C=0.18	row: 236
UWM_Clark_14AS	SA04C2_2.txt	H:C=0.19	row: 237
UWM_Clark_14AS	SA04C2_3.txt	H:C=0.19	row: 238
UWM_Clark_14AS	SA04C2_4.txt	H:C=0.11	row: 239
UWM_Clark_14AS	SA04C2_5.txt	H:C=0.22	row: 240
UWM_Clark_14AS	SA05B1_4.txt	H:C=0.14	row: 241
UWM_Clark_14AS	SA05B1_5.txt	H:C=0.15	row: 242
UWM_Clark_14AS	SA05B1_6.txt	H:C=0.19	row: 243
UWM_Clark_14AS	SA05B2_1.txt	H:C=0.16	row: 244
UWM_Clark_14AS	SA05B2_4.txt	H:C=0.13	row: 245
UWM_Clark_14AS	SA05B2_5.txt	H:C=0.16	row: 246
UWM_Clark_14AS	SA05B2_6.txt	H:C=0.14	row: 247
UWM_Clark_14AS	SA05B3_1.txt	H:C=0.2	row: 248
UWM_Clark_14AS	SA05B3_2.txt	H:C=0.15	row: 249
UWM_Clark_14AS	SA05B3_3.txt	H:C=0.11	row: 250
UWM_Clark_14AS	SA05B3_5.txt	H:C=0.19	row: 251
UWM_Clark_14AS	SA05B3_6.txt	H:C=0.19	row: 252
UWM_Clark_14AS	SA05B4_1.txt	H:C=0.12	row: 253
UWM_Clark_14AS	SA05B4_2.txt	H:C=0.17	row: 254
UWM_Clark_14AS	SA05B4_3.txt	H:C=0.18	row: 255
UWM_Clark_14AS	SA05B4_5.txt	H:C=0.12	row: 256
UWM_Clark_14AS	SA05B4_6.txt	H:C=0.19	row: 257
UWM_Clark_14AS	SA05B5_1.txt	H:C=0.15	row: 258
UWM_Clark_14AS	SA05B5_2.txt	H:C=0.2	row: 259
UWM_Clark_14AS	SA05B5_3.txt	H:C=0.14	row: 260
UWM_Clark_14AS	SA05B5_4.txt	H:C=0.12	row: 261
UWM_Clark_14AS	SA05B5_5.txt	H:C=0.15	row: 262
UWM_Clark_14AS	SA05B5_6.txt	H:C=0.17	row: 263
UWM_Clark_14AS	SA05B6_1.txt	H:C=0.18	row: 264
UWM_Clark_14AS	SA05B6_2.txt	H:C=0.13	row: 265
UWM_Clark_14AS	SA05B6_3.txt	H:C=0.17	row: 266
UWM_Clark_14AS	SA05B6_4.txt	H:C=0.16	row: 267
UWM_Clark_14AS	SA05B6_5.txt	H:C=0.11	row: 268
UWM_Clark_14AS	SA05B6_6.txt	H:C=0.18	row: 269
UWM_Clark_14AS	SA06A_2.txt	H:C=0.17	row: 270
UWM_Clark_14AS	SA06A_5.txt	H:C=0.16	row: 271
UWM_Clark_14AS	SA06B_2.txt	H:C=0.14	row: 272
UWM_Clark_14AS	SA06B_4.txt	H:C=0.14	row: 273
UWM_Clark_14AS	SA11A_1.txt	H:C=0.2	row: 274
UWM_Clark_14AS	SA11A_5.txt	H:C=0.2	row: 275
UWM_Clark_14AS	SA11A_2.txt	H:C=0.23	row: 276
UWM_Clark_14AS	SA11B_1.txt	H:C=0.18	row: 277
UWM_Clark_14AS	SA11B_3.txt	H:C=0.19	row: 278
UWM_Clark_14AS	SA11B_4.txt	H:C=0.16	row: 279
UWM_Clark_14AS	SA11B_5.txt	H:C=0.17	row: 280
UWM_Clark_14AS	SA11B_6.txt	H:C=0.17	row: 281
UWM_Clark_14AS	SA12A_1.txt	H:C=0.12	row: 282
UWM_Clark_14AS	SA12A_2.txt	H:C=0.12	row: 283
UWM_Clark_14AS	SA12A_3.txt	H:C=0.14	row: 284
UWM_Clark_14AS	SA12A_4.txt	H:C=0.15	row: 285
UWM_Clark_14AS	SA12A_5.txt	H:C=0.12	row: 286
UWM_Clark_14AS	SA12A_6.txt	H:C=0.16	row: 287
UWM_Clark_14AS	SA13B1_4.txt	H:C=0.13	row: 288
UWM_Clark_14AS	SA13B1_5.txt	H:C=0.13	row: 289
UWM_Clark_14AS	SA13B1_6.txt	H:C=0.12	row: 290
UWM_Clark_14AS	SA13B2_1.txt	H:C=0.14	row: 291
UWM_Clark_14AS	SA13B2_2.txt	H:C=0.15	row: 292
UWM_Clark_14AS	SA13B2_3.txt	H:C=0.18	row: 293
UWM_Clark_14AS	SA13B3_1.txt	H:C=0.11	row: 294
UWM_Clark_14AS	SA13B3_2.txt	H:C=0.16	row: 295
UWM_Clark_14AS	SA13B3_3.txt	H:C=0.15	row: 296
UWM_Clark_14AS	SA13B3_4.txt	H:C=0.13	row: 297
UWM_Clark_14AS	SA13B3_5.txt	H:C=0.13	row: 298
UWM_Clark_14AS	SA13B3_6.txt	H:C=0.16	row: 299
UWM_Clark_14AS	SA13B4_1.txt	H:C=0.19	row: 300
UWM_Clark_14AS	SA13B4_2.txt	H:C=0.15	row: 301
UWM_Clark_14AS	SA13B4_3.txt	H:C=0.15	row: 302
UWM_Clark_14AS	SA13B4_6.txt	H:C=0.16	row: 303
UWM_Clark_14AS	SA14AB1_1.txt	H:C=0.12	row: 304
UWM_Clark_14AS	SA14AB1_2.txt	H:C=0.13	row: 305
UWM_Clark_14AS	SA14AB1_3.txt	H:C=0.15	row: 306
UWM_Clark_14AS	SA14AB1_4.txt	H:C=0.14	row: 307
UWM_Clark_14AS	SA14AB1_5.txt	H:C=0.15	row: 308
UWM_Clark_14AS	SA14AB1_6.txt	H:C=0.15	row: 309
UWM_Clark_14AS	SA14AB2_1.txt	H:C=0.18	row: 310
UWM_Clark_14AS	SA14AB2_2.txt	H:C=0.18	row: 311
UWM_Clark_14AS	SA14AB2_3.txt	H:C=0.12	row: 312
UWM_Clark_14AS	SA14AB2_4.txt	H:C=0.14	row: 313
UWM_Clark_14AS	SA14AB2_5.txt	H:C=0.17	row: 314
UWM_Clark_14AS	SA14AB2_6.txt	H:C=0.15	row: 315
UWM_Clark_14AS	SA14AB3_1.txt	H:C=0.14	row: 316
UWM_Clark_14AS	SA14AB3_2.txt	H:C=0.19	row: 317
UWM_Clark_14AS	SA14AB3_3.txt	H:C=0.11	row: 318
UWM_Clark_14AS	SA14AB3_5.txt	H:C=0.11	row: 319
UWM_Clark_14AS	SA14AB4_1.txt	H:C=0.15	row: 320
UWM_Clark_14AS	SA14AB4_2.txt	H:C=0.14	row: 321
UWM_Clark_14AS	SA14AB4_3.txt	H:C=0.14	row: 322
UWM_Clark_14AS	SA14AB4_4.txt	H:C=0.15	row: 323
UWM_Clark_14AS	SA14AB4_5.txt	H:C=0.18	row: 324
UWM_Clark_14AS	SA14AB4_6.txt	H:C=0.16	row: 325
UWM_Clark_14AS	SA14B1_1.txt	H:C=0.12	row: 326
UWM_Clark_14AS	SA14B1_2.txt	H:C=0.172	row: 327
UWM_Clark_14AS	SA14B1_3.txt	H:C=0.12	row: 328
UWM_Clark_14AS	SA14B1_4.txt	H:C=0.15	row: 329
UWM_Clark_14AS	SA14B1_5.txt	H:C=0.17	row: 330
UWM_Clark_14AS	SA14B1_6.txt	H:C=0.17	row: 331
UWM_Clark_14AS	SA15BA1_1.txt	H:C=0.14	row: 332
UWM_Clark_14AS	SA15BA1_2.txt	H:C=0.13	row: 333
UWM_Clark_14AS	SA15BA1_3.txt	H:C=0.19	row: 334
UWM_Clark_14AS	SA15BA1_5.txt	H:C=0.11	row: 335
UWM_Clark_14AS	SA15BA1_6.txt	H:C=0.16	row: 336
UWM_Clark_14AS	SA15BA2_1.txt	H:C=0.19	row: 337
UWM_Clark_14AS	SA15BA2_3.txt	H:C=0.12	row: 338
UWM_Clark_14AS	SA15BA2_4.txt	H:C=0.12	row: 339
UWM_Clark_14AS	SA15BA3_1.txt	H:C=0.15	row: 340
UWM_Clark_14AS	SA15BA3_2.txt	H:C=0.12	row: 341
UWM_Clark_14AS	SA15BA3_4.txt	H:C=0.16	row: 342
UWM_Clark_14AS	SA15BA3_5.txt	H:C=0.12	row: 343
UWM_Clark_14AS	SA15BB_1.txt	H:C=0.12	row: 344
UWM_Clark_14AS	SA15BB_2.txt	H:C=0.16	row: 345
UWM_Clark_14AS	SA15BB_4.txt	H:C=0.19	row: 346
UWM_Clark_14AS	SA15BB_5.txt	H:C=0.14	row: 347
UWM_Clark_14AS	SA15BB_6.txt	H:C=0.12	row: 348
